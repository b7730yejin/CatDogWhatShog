package com.demo.cdmall1.domain.imageboard.entity;

import java.io.*;

public class ImageBoardMemberId implements Serializable {
	private String username;
	private Integer ibno;
}
