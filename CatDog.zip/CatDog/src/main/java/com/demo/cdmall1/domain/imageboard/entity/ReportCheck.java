package com.demo.cdmall1.domain.imageboard.entity;

public enum ReportCheck {
	DO_REPORT, GET_REPORT, SUB_REPORT
}
