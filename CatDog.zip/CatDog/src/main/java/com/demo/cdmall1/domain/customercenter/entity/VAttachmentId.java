package com.demo.cdmall1.domain.customercenter.entity;

import java.io.*;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
public class VAttachmentId implements Serializable {
	private Integer vocBoard;
	private Integer ano;
}