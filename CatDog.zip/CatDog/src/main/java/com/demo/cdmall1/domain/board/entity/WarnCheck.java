package com.demo.cdmall1.domain.board.entity;

public enum WarnCheck {
	DO_WARN, GET_WARN, SUB_WARM
}
