package com.demo.cdmall1.domain.member.service;


public class AdminService {

}
