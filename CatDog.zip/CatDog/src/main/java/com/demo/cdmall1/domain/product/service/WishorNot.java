package com.demo.cdmall1.domain.product.service;

public enum WishorNot {
	DO_LIKE, GET_DISLIKE, DO_DISLIKE, GET_LIKE;
}
