package com.demo.cdmall1.domain.questionboard.entity;

import org.springframework.data.repository.*;

public interface QSAttachmentRepository extends CrudRepository<QSAttachment, Integer>{

}
