package com.demo.cdmall1.domain.member.service;

public enum GoodOrBad {
	// 추천하고 추천수 리턴, 비추하고 비추수 리턴, 이미 추천해서 현재 추천수 리턴, 이미 추천해서 비추수 리턴
	DO_GOOD, DO_BAD, GET_GOOD, GET_BAD, SUB_GOOD, SUB_BAD;
}
