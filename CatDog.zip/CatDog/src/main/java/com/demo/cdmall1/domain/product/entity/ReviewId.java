package com.demo.cdmall1.domain.product.entity;

import java.io.*;

public class ReviewId implements Serializable {
	private Integer product;
	private Integer rno;
}
