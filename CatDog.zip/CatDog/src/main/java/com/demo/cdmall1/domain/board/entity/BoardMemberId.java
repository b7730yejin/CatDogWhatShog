package com.demo.cdmall1.domain.board.entity;

import java.io.*;

public class BoardMemberId implements Serializable {
	private String username;
	private Integer bno;
}
