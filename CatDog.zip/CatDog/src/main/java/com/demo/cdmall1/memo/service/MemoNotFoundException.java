package com.demo.cdmall1.memo.service;

public class MemoNotFoundException extends RuntimeException {

}
