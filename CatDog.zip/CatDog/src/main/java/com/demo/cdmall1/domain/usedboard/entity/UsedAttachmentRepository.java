package com.demo.cdmall1.domain.usedboard.entity;

import org.springframework.data.repository.*;

public interface UsedAttachmentRepository extends CrudRepository<UsedAttachment, Integer>{

}
