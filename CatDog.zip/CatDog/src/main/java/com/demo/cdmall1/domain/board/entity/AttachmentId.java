package com.demo.cdmall1.domain.board.entity;

import java.io.*;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
public class AttachmentId implements Serializable {
	private Integer board;
	private Integer ano;
}