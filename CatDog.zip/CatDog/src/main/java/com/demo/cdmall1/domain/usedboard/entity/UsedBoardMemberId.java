package com.demo.cdmall1.domain.usedboard.entity;

import java.io.*;

public class UsedBoardMemberId implements Serializable {
	private String username;
	private Integer ubno;
}
