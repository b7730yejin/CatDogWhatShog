package com.demo.cdmall1.domain.noticeboard.entity;

import org.springframework.data.repository.*;

public interface NBAttachmentRepository extends CrudRepository<NBAttachment, Integer>{

}
