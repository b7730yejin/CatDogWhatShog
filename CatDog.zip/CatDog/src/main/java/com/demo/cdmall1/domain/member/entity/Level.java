package com.demo.cdmall1.domain.member.entity;

public enum Level {
	BRONZE, SILVER, GOLD;
}
