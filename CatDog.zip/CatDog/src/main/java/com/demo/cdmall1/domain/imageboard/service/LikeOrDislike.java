package com.demo.cdmall1.domain.imageboard.service;

public enum LikeOrDislike {
	// 추천하고 추천수 리턴, 비추하고 비추수 리턴, 이미 추천해서 현재 추천수 리턴, 이미 추천해서 비추수 리턴
	DO_LIKE, GET_DISLIKE, DO_DISLIKE, GET_LIKE;
}
