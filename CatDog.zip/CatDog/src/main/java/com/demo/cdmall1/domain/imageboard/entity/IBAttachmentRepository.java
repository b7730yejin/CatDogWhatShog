package com.demo.cdmall1.domain.imageboard.entity;

import org.springframework.data.repository.*;

public interface IBAttachmentRepository extends CrudRepository<IBAttachment, Integer>{

}
